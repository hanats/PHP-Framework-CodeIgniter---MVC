<?php
defined('BASEPATH') OR exit('No direct script access allowed');
?>
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8">
	<title>Welcome to CodeIgniter</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-1BmE4kWBq78iYhFldvKuhfTAU6auU8tT94WrHftjDbrCEXSU1oBoqyl2QvZ6jIW3" crossorigin="anonymous">
</head>
<body class="container">
    <h3>Daftar Dosen</h3>
    <table class="table table-striped">
        <thead>
            <tr class="text-center">
                <th>#</th><th>NIDN</th><th>Nama</th><th>Gender</th>
                <th>Prodi</th>
            </tr>
        </thead>
        <tbody>
        Web Programming | STT-NF
        5
        Praktikum 8: PHP Framework CodeIgniter - MVC
        <?php
            $nomor=1;
            foreach($list_dsn as $dsn){
        ?>
            <tr class="text-center">
                <td><?=$nomor?></td>
                <td><?=$dsn->nidn?></td>
                <td><?=$dsn->nama?></td>
                <td><?=$dsn->gender?></td>
                <td><?=$dsn->prodi?></td>
            </tr>
            <?php
            $nomor++;
            }
            ?>
        </tbody>
    </table>
</body>
</html>